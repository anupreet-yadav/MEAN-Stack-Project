const { error } = require('console');
const express = require('express')
const mongoose = require('mongoose');
const app = express()
const port = 3000
const cors = require('cors');

const userRoutes = require('./routes/user-routes')

app.use(cors());
app.get('/', (req, res) => {
  res.send('Hello World!')
})
app.use(express.json());

app.use(userRoutes)

async function connectDb() {
  await mongoose.connect("mongodb://localhost:27017", {
    dbName: "UserDb",
  });
}

connectDb().catch((err)=>console.error(err));

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})