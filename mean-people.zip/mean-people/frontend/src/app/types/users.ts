export default interface User {
_id?: string;
name: string; 
email: string; 
age: number;
address: string; 
}