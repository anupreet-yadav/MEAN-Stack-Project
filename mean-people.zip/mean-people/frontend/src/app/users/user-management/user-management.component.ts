// user-management.component.ts
import { Component, inject } from '@angular/core';
import { ReactiveFormsModule, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { CommonModule } from '@angular/common';
import User from '../../types/users';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [MatInputModule, MatButtonModule, ReactiveFormsModule, CommonModule],
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent {
  formBuilder = inject(FormBuilder);
  userForm: FormGroup = this.formBuilder.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    age: [''],
    address: ['']
  });

  userService = inject(UserService);
  users: User[] = [];
  editUserId: string | null = null;
  showForm = false;

  ngOnInit() {
    this.loadUsers();
  }

  loadUsers() {
    this.userService.getUsers().subscribe((result) => {
      this.users = result;
    });
  }

  showAddForm() {
    this.userForm.reset();
    this.editUserId = null;
    this.showForm = true;
  }

  editUser(user: User) {
    this.editUserId = user._id!;
    this.userForm.patchValue({
      name: user.name,
      email: user.email,
      age: user.age,
      address: user.address
    });
    this.showForm = true;
  }

  cancelForm() {
    this.showForm = false;
    this.userForm.reset();
    this.editUserId = null;
  }

  addUser() {
    if (this.userForm.invalid) {
      alert("Please provide all fields with valid data");
      return;
    }
    const model: User = this.userForm.value;
    this.userService.addUser(model).subscribe(result => {
      alert("User added successfully.");
      this.loadUsers();
      this.cancelForm();
    });
  }

  updateUser() {
    if (this.userForm.invalid) {
      alert("Please provide all fields with valid data");
      return;
    }
    const model: User = this.userForm.value;
    this.userService.updateUser(this.editUserId!, model).subscribe((result) => {
      alert("User updated successfully");
      this.loadUsers();
      this.cancelForm();
    });
  }

  delete(id: string) {
    const ok = confirm("Are you sure you want to delete this user?");
    if (ok) {
      this.userService.deleteUser(id).subscribe((result) => {
        alert("User deleted successfully!");
        this.users = this.users.filter((u) => u._id != id);
      });
    }
  }
}